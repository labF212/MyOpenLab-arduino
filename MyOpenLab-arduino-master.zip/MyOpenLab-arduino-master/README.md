# MyOpenLab-arduino
Read data from Arduino and show it in a graph and save the data to a csv file.
View the wiki page for details.

# MyOpenLab-arduino
Ler dados do arduino e mostrá-los num gráfico em tempo real e guardá-los num ficheiro csv.
Veja a página wiki para mais detalhes.
